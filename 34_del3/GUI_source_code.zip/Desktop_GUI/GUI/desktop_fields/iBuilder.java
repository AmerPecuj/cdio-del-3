package desktop_fields;

public interface iBuilder {
    
    public Field build();
}
